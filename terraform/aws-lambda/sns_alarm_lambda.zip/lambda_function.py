import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """Process SNS alarm messages"""
    try:
        for record in event['Records']:
            sns_message = json.loads(record['Sns']['Message'])
            logger.info(f"Processing alarm: {sns_message.get('AlarmName', 'Unknown')}")
            
            # Process alarm logic here
            # This could trigger emails, update DynamoDB, etc.
            
        return {
            'statusCode': 200,
            'body': json.dumps('Alarm processed successfully')
        }
    except Exception as e:
        logger.error(f"Error processing alarm: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
